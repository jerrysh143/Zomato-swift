//
//  ViewController.swift
//  ZomTask
//
//  Created by Tops on 5/25/17.
//  Copyright © 2017 jay. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource{
  
    
    @IBOutlet weak var txlData: UITableView!
    var arrData = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    let q  = ""
        Alamofire.request(.GET, "https://developers.zomato.com/api/v2.1/search?lat=23.0225&lon=72.5714", parameters: ["q" : q])
            .responseJSON { response in
                let JSONObject = JSON(response.result.value!)
                self.results = JSONObject["things"]
                for (key, _) in self.results {
                    let intKey: Int = Int(key)!
                    var thisItem: JSON = self.results[intKey]
                    let geoLat = thisItem["photos_url"][0]["city"][1].double ?? 23.0225
                    let geoLong = thisItem["photos_url"][0]["city"][0].double ?? 72.5714
                    let destination = CLLocation(latitude: geoLat, longitude: geoLong)
                    let setLocation = CLLocation(latitude: self.currentLocation.latitude, longitude: self.currentLocation.longitude)
                    let distanceBetween: CLLocationDistance = destination.distanceFromLocation(setLocation)
                    thisItem["distance"].double =  distanceBetween
                    self.results[intKey] = thisItem
                }
                self.tableView.reloadData()
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        let row = arrData[indexPath.row] as! [String:Any]
        cell.imageview.image = row["photos_url"] as? UIImage
        cell.lbl?.text = row["name"] as? String
        cell.backgroundColor = UIColor.black
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
