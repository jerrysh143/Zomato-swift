//
//  ViewController.swift
//  ZomTask
//
//  Created by Tops on 5/25/17.
//  Copyright © 2017 jay. All rights reserved.
//

import UIKit


//https://developers.zomato.com/api/v2.1/search?lat=23.0225&lon=72.5714

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate{
  
    
    var arrData = [[String:Any]]()
    
    var imageArr = [UIImage]()
    
    
    var filterarrData = [[String:Any]]()
    
    var filterimageArr = [UIImage]()
    
    
    let act:UIActivityIndicatorView = UIActivityIndicatorView()
    
    
    
    
    @IBOutlet weak var searchBarView: UISearchBar!
    var str = ""
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showweb"
        {
            let dest = segue.destination as! WebViewViewController
            dest.strUrl = str
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
    
        filterarrData = [[String:Any]]()
        
        filterimageArr = [UIImage]()

        let matchto = searchBar.text
        for i in 0..<self.arrData.count
        {
            let row = self.arrData[i]["restaurant"] as! [String:Any]
            let matchwith = row["name"] as? String
            
            if (matchwith?.contains(matchto!))!
            {
                self.filterarrData.append(self.arrData[i])
                self.filterimageArr.append(imageArr[i])
            }
            
        }
        
        print(self.filterarrData)
     
        if self.filterarrData.count > 0
        {
            self.table.reloadData()
        }
        self.table.reloadData()

    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        
    }
    func searchBarShouldBeginEditing(searchBar: UISearchBar) -> Bool
    {
        UIApplication.shared.statusBarStyle = .lightContent
        self.setNeedsStatusBarAppearanceUpdate()
        return true
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        act.center = self.view.center
        act.activityIndicatorViewStyle = .gray
        self.view.addSubview(act)
        act.startAnimating()
        act.hidesWhenStopped = true
        
        let zomatoKey = "f167af2375530fc913d8c785afb73b3b"
        let zomatoURLString = "https://developers.zomato.com/api/v2.1/search?lat=23.0225&lon=72.5714"
        let url = NSURL(string: zomatoURLString)
        
        if url != nil {
            let request = NSMutableURLRequest(url: url! as URL)
            request.httpMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.addValue(zomatoKey, forHTTPHeaderField: "user-key")
            
            let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: {
                (data,response,error) -> Void in
                
                if let error = error {
                    print(error)
                }
                
                //Parse Json data
                
                if let data = data {
                    do{
                        let jsonData = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves) as? [String:Any]
                        
                        let dtarr = jsonData?["restaurants"] as! [[String:Any]]
                        //self.arrData = ArrData?["restaurant"] as! [[String:Any]]
                        
                        for i in 0..<dtarr.count
                        {
                            self.arrData.append(dtarr[i])
                            let row = self.arrData[i]["restaurant"] as! [String:Any]
                            
                            do{
                                print("row is :",row)
                                
                                let url = URL.init(string: row["thumb"]! as! String)
                                if url == nil{
                                    let image = UIImage.init(named: "No Preview")
                                    self.imageArr.append(image!)
                                }
                                else{
                                    let urlsession = URLSession.init(configuration: URLSessionConfiguration.default)
                                    
                                    let task = urlsession.dataTask(with: url!, completionHandler: {data,res,err in
                                        
                                        if data == nil{
                                            
                                        }
                                        else{
                                            
                                            let img = UIImage.init(data: data!)
                                            self.imageArr.append(img!)
                                            
                                        }
                                        
                                    })
                                    task.resume()
                                }
                            }
                            catch
                            {
                                print(error.localizedDescription)
                            }
                            self.table.reloadData()
                            
                        }
                        self.act.stopAnimating()
                        
                        print("\n\n\nData is:",self.arrData)
                        //                        let str = String.init(bytes: data, encoding: .utf8)
                        //                        print("Str is", str as Any)
                        //                        for a in self.arrData
                        //                        {
                        //                            print(a)
                        //                        }
                        
                    }
                    catch{
                        print("errr" , error)
                    }
                    //   self.getRestaurants = self.parseJsonData(data)
                    
                    print(data)
                    
                    //reload table
                    OperationQueue.main.addOperation({() -> Void in
                        //                        self.tableview.reloadData()
                        
                    })
                    
                }
            })
            
            task.resume()
            
        }

    }
    
    
    @IBOutlet weak var table: UITableView!
   
    
   
 func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if(filterarrData.count==0)
        {
            return self.arrData.count
        }
        return self.filterarrData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        
        var row = [String:Any]()
        var img = UIImage()
        
        
        
        if(filterarrData.count==0)
        {
            row = self.arrData[indexPath.row]["restaurant"] as! [String:Any]
            img = self.imageArr[indexPath.row]
        }
        else{
            
            row = self.filterarrData[indexPath.row]["restaurant"] as! [String:Any]
            img = self.filterimageArr[indexPath.row]
   
        }
        cell.restname.text = row["name"] as? String
        cell.cuziness.text = row["cuisines"] as? String
        cell.addresss.text = row["locality"] as? String
        cell.imageview.image = self.imageArr[indexPath.row]
        
       
                return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var row = [String:Any]()
        
        
        
        if(filterarrData.count==0)
        {
            row = self.arrData[indexPath.row]["restaurant"] as! [String:Any]
        }
        else{
            
            row = self.filterarrData[indexPath.row]["restaurant"] as! [String:Any]
            
        }
        
        str = row["url"] as! String
        performSegue(withIdentifier: "showweb", sender: self)
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
       override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



}
